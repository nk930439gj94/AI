import random

def decide(instr):
    prob = random.uniform(0, 1)
    if(prob > 0.5):
    	dire = 1
    else:
        dire = -1
    
    return dire
